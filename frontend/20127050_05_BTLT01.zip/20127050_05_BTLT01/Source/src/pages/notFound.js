import React, { Component } from 'react';

export default class NotFound extends Component {
  render() {
    console.log('mct report error');
    return (
      <div>
        Not Found
      </div>
    );
  }
}
