import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

const Layout = () => {
  const a = 0;

  return (
    <div>
      Layout
    </div>
  );
};

Layout.propTypes = {

};

export default Layout;
